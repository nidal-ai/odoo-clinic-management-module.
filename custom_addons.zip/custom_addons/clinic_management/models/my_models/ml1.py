import tensorflow as tf
from tensorflow.keras import layers, models
import numpy as np

# Charger le dataset MNIST (chiffres manuscrits)
(x_train, y_train), (x_test, y_test) = tf.keras.datasets.mnist.load_data()

# Prétraiter les données
x_train, x_test = x_train / 255.0, x_test / 255.0  # Normalisation des images

# Créer un modèle de réseau de neurones
model = models.Sequential([
    layers.Flatten(input_shape=(28, 28)),  # Aplatir les images 28x28 en un vecteur 1D
    layers.Dense(128, activation='relu'),  # Couche dense avec 128 neurones
    layers.Dense(10, activation='softmax')  # Couche de sortie (10 classes, chiffres 0-9)
])

# Compiler le modèle
model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])

# Entraîner le modèle
model.fit(x_train, y_train, epochs=5)

# Évaluer le modèle sur les données de test
test_loss, test_acc = model.evaluate(x_test, y_test)

print(f"Test accuracy: {test_acc}")