from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
from datetime import datetime, timedelta

class Appointment(models.Model):
    _name = 'clinic.appointment'
    _description = 'Clinic Appointment'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'appointment_datetime desc'

    name = fields.Char(string='Reference', required=True, readonly=True, default='New')
    patient_id = fields.Many2one('clinic.patient', string='Patient', required=True)
    doctor_id = fields.Many2one('clinic.doctor', string='Doctor', required=True)
    appointment_datetime = fields.Datetime(string='Appointment Time', required=True)
    duration = fields.Float(string='Duration', default=0.5, help='Duration in hours')
    state = fields.Selection([
        ('draft', 'Draft'),
        ('confirm', 'Confirmed'),
        ('done', 'Done'),
        ('cancel', 'Cancelled'),
    ], string='Status', default='draft', tracking=True)
    notes = fields.Text(string='Notes')
    prescription = fields.Text(string='Prescription')

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', 'New') == 'New':
                vals['name'] = self.env['ir.sequence'].next_by_code('clinic.appointment') or 'New'
        return super(Appointment, self).create(vals_list)

    def action_confirm(self):
        self.state = 'confirm'

    def action_done(self):
        self.state = 'done'

    def action_cancel(self):
        self.state = 'cancel'

    def action_draft(self):
        self.state = 'draft'

    @api.constrains('appointment_datetime')
    def _check_appointment_datetime(self):
        for record in self:
            if record.appointment_datetime and record.appointment_datetime < fields.Datetime.now():
                raise ValidationError(_("Appointment time cannot be in the past!"))

    @api.constrains('doctor_id', 'appointment_datetime', 'duration')
    def _check_doctor_availability(self):
        for record in self:
            domain = [
                ('doctor_id', '=', record.doctor_id.id),
                ('state', 'in', ['draft', 'confirm']),
                ('id', '!=', record.id),
                '|',
                '&',
                ('appointment_datetime', '<=', record.appointment_datetime),
                ('appointment_datetime', '>=', record.appointment_datetime - timedelta(hours=record.duration)),
                '&',
                ('appointment_datetime', '>=', record.appointment_datetime),
                ('appointment_datetime', '<=', record.appointment_datetime + timedelta(hours=record.duration)),
            ]
            if self.search_count(domain) > 0:
                raise ValidationError(_("Doctor already has an appointment scheduled during this time!"))
