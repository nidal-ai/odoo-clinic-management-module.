{
    'name': 'Clinic Management System',
    'version': '1.0',
    'category': 'Healthcare',
    'summary': 'Manage clinic operations, doctors, and patients',
    'description': """
        Clinic Management System Features:
        - Patient Management
        - Doctor Management
        - Appointment Scheduling
        - Medical Records
        - Prescription Management
    """,
    'depends': ['base', 'mail'],
    'data': [
        'security/clinic_security.xml',
        'security/ir.model.access.csv',
        'data/sequence.xml',
        'views/doctor_views.xml',
        'views/patient_views.xml',
        'views/appointment_views.xml',
        'views/clinic_menus.xml',
    ],
    'demo': [],
    'installable': True,
    'application': True,
    'auto_install': False,
    'license': 'LGPL-3',
}
